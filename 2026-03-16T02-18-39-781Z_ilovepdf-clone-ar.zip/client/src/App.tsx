import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import Login from "@/pages/Login";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import { LanguageProvider } from "./contexts/LanguageContext";
import Home from "./pages/Home";
import MergePDF from "./pages/MergePDF";
import SplitPDF from "./pages/SplitPDF";
import JpgToPdf from "./pages/JpgToPdf";
import ImageConverter from "./pages/ImageConverter";
import ImageResize from "./pages/ImageResize";
import ImageCompress from "./pages/ImageCompress";
import ToolComingSoon from "./pages/ToolComingSoon";

function Router() {
  // make sure to consider if you need authentication for certain routes
  return (
    <Switch>
      <Route path={"/"} component={Home} />
      <Route path={"/merge"} component={MergePDF} />
      <Route path={"/split"} component={SplitPDF} />
      <Route path={"/compress"} component={ToolComingSoon} />
      <Route path={"/pdf-to-word"} component={ToolComingSoon} />
      <Route path={"/pdf-to-ppt"} component={ToolComingSoon} />
      <Route path={"/pdf-to-excel"} component={ToolComingSoon} />
      <Route path={"/word-to-pdf"} component={ToolComingSoon} />
      <Route path={"/ppt-to-pdf"} component={ToolComingSoon} />
      <Route path={"/excel-to-pdf"} component={ToolComingSoon} />
      <Route path={"/edit"} component={ToolComingSoon} />
      <Route path={"/pdf-to-jpg"} component={ImageConverter} />
      <Route path={"/jpg-to-pdf"} component={JpgToPdf} />
      <Route path={"/image-converter"} component={ImageConverter} />
      <Route path={"/image-resize"} component={ImageResize} />
      <Route path={"/image-compress"} component={ImageCompress} />
      <Route path={"/page-numbers"} component={ToolComingSoon} />
      <Route path={"/watermark"} component={ToolComingSoon} />
      <Route path={"/rotate"} component={ToolComingSoon} />
      <Route path={"/protect"} component={ToolComingSoon} />
      <Route path={"/login"} component={Login} />
      <Route path={"/404"} component={NotFound} />
      {/* Final fallback route */}
      <Route component={NotFound} />
    </Switch>
  );
}

// NOTE: About Theme
// - First choose a default theme according to your design style (dark or light bg), than change color palette in index.css
//   to keep consistent foreground/background color across components
// - If you want to make theme switchable, pass `switchable` ThemeProvider and use `useTheme` hook

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider
        defaultTheme="light"
        // switchable
      >
        <LanguageProvider>
          <TooltipProvider>
            <Toaster />
            <Router />
          </TooltipProvider>
        </LanguageProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;

import { PDFToolPage } from "@/components/PDFToolPage";
import { FileImage } from "lucide-react";
import { PDFDocument } from "pdf-lib";
import { useLanguage } from "@/contexts/LanguageContext";

export default function JpgToPdf() {
  const { t } = useLanguage();
  const handleConvert = async (files: File[]) => {
    if (files.length === 0) return;

    const pdfDoc = await PDFDocument.create();

    for (const file of files) {
      const arrayBuffer = await file.arrayBuffer();
      let image;
      
      if (file.type === "image/jpeg" || file.type === "image/jpg") {
        image = await pdfDoc.embedJpg(arrayBuffer);
      } else if (file.type === "image/png") {
        image = await pdfDoc.embedPng(arrayBuffer);
      } else {
        continue; // Skip unsupported types for now
      }

      const page = pdfDoc.addPage([image.width, image.height]);
      page.drawImage(image, {
        x: 0,
        y: 0,
        width: image.width,
        height: image.height,
      });
    }

    const pdfBytes = await pdfDoc.save();
    const blob = new Blob([pdfBytes as any], { type: "application/pdf" });
    const url = URL.createObjectURL(blob);
    
    const a = document.createElement("a");
    a.href = url;
    a.download = "images_to_pdf.pdf";
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <PDFToolPage
      title={t('tool_jpg2pdf_title')}
      description={t('tool_jpg2pdf_desc')}
      actionLabel={t('btn_convert')}
      onProcess={handleConvert}
      icon={<FileImage className="w-10 h-10 text-yellow-600" />}
      isImage
    />
  );
}

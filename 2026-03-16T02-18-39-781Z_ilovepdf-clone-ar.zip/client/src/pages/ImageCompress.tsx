import { useState, useCallback } from "react";
import { Layout } from "@/components/Layout";
import { Button } from "@/components/ui/button";
import { Upload, X, Minimize, AlertCircle, Loader2, Zap } from "lucide-react";
import { useDropzone } from "react-dropzone";
import { toast } from "sonner";
import { Slider } from "@/components/ui/slider";
import { useLanguage } from "@/contexts/LanguageContext";

export default function ImageCompress() {
  const { t } = useLanguage();
  const [files, setFiles] = useState<File[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [quality, setQuality] = useState([80]);

  const onDrop = useCallback((acceptedFiles: File[]) => {
    const imageFiles = acceptedFiles.filter(file => file.type.startsWith("image/"));
    if (imageFiles.length < acceptedFiles.length) {
      toast.error(t('error_img_only'));
    }
    setFiles(prev => [...prev, ...imageFiles]);
  }, [t]);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: { 'image/*': [] },
    multiple: true
  });

  const removeFile = (index: number) => {
    setFiles(prev => prev.filter((_, i) => i !== index));
  };

  const compressImage = (file: File, qualityValue: number): Promise<Blob> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        const img = new Image();
        img.onload = () => {
          const canvas = document.createElement('canvas');
          canvas.width = img.width;
          canvas.height = img.height;
          const ctx = canvas.getContext('2d');
          if (!ctx) return reject(new Error("Failed to get canvas context"));
          ctx.drawImage(img, 0, 0);
          
          // Only JPG and WebP support quality compression in toBlob
          const mimeType = file.type === "image/png" ? "image/jpeg" : file.type;
          canvas.toBlob((blob) => {
            if (blob) resolve(blob);
            else reject(new Error("Compression failed"));
          }, mimeType, qualityValue / 100);
        };
        img.onerror = reject;
        img.src = e.target?.result as string;
      };
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  };

  const handleProcess = async () => {
    if (files.length === 0) return;
    setIsProcessing(true);
    try {
      for (const file of files) {
        const compressedBlob = await compressImage(file, quality[0]);
        const url = URL.createObjectURL(compressedBlob);
        const a = document.createElement("a");
        a.href = url;
        const ext = file.type === "image/png" ? "jpg" : file.name.split('.').pop();
        a.download = `compressed_${file.name.split('.')[0]}.${ext}`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
      }
      toast.success(t('success_msg'));
    } catch (error) {
      toast.error(t('error_msg'));
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <Layout>
      <div className="bg-white border-b border-gray-200">
        <div className="container mx-auto px-4 py-12 text-center">
          <div className="inline-flex p-4 bg-green-50 rounded-2xl mb-6">
            <Minimize className="w-10 h-10 text-green-600" />
          </div>
          <h1 className="text-3xl font-black text-slate-800 mb-4">{t('tool_compress_title')}</h1>
          <p className="text-slate-500 max-w-2xl mx-auto font-medium">{t('tool_compress_desc')}</p>
        </div>
      </div>

      <div className="py-12 bg-[#f3f3f3] min-h-[500px]">
        <div className="container mx-auto px-4 max-w-4xl">
          {files.length === 0 ? (
            <div 
              {...getRootProps()} 
              className={`
                border-4 border-dashed rounded-3xl p-16 text-center cursor-pointer transition-all
                ${isDragActive ? 'border-green-500 bg-green-50' : 'border-gray-300 bg-white hover:border-green-500/50 hover:bg-green-50/10'}
              `}
            >
              <input {...getInputProps()} />
              <div className="flex flex-col items-center">
                <div className="w-20 h-20 bg-green-50 rounded-full flex items-center justify-center mb-6">
                  <Upload className="w-10 h-10 text-green-600" />
                </div>
                <h3 className="text-2xl font-black text-slate-800 mb-3">{t('choose_images')}</h3>
                <p className="text-slate-500 font-medium mb-8">{t('drop_images')}</p>
                <Button size="lg" className="bg-green-600 hover:bg-green-700 text-white px-12 py-7 text-xl font-black rounded-xl">
                  {t('choose_images')}
                </Button>
              </div>
            </div>
          ) : (
            <div className="space-y-6">
              <div className="bg-white p-8 rounded-2xl border border-gray-200 shadow-sm">
                <div className="flex items-center justify-between mb-8">
                  <div className="flex items-center gap-2 text-green-600 font-black">
                    <Zap className="w-5 h-5" />
                    <span>{t('quality_level')} {quality[0]}%</span>
                  </div>
                  <span className="text-sm font-bold text-slate-400">
                    {quality[0] > 70 ? t('high_quality') : quality[0] > 40 ? t('good_balance') : t('high_compression')}
                  </span>
                </div>
                
                <Slider 
                  value={quality} 
                  onValueChange={setQuality} 
                  max={100} 
                  step={1} 
                  className="mb-10"
                />
                
                <div className="flex justify-center">
                  <Button 
                    onClick={handleProcess}
                    disabled={isProcessing}
                    size="lg" 
                    className="bg-green-600 hover:bg-green-700 text-white px-20 py-8 text-2xl font-black rounded-2xl shadow-xl shadow-green-500/20"
                  >
                    {isProcessing ? <Loader2 className="animate-spin ml-2" /> : null}
                    {isProcessing ? t('processing') : t('btn_start_compress')}
                  </Button>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                {files.map((file, index) => (
                  <div key={index} className="bg-white p-4 rounded-xl border border-gray-200 shadow-sm relative group">
                    <button 
                      onClick={() => removeFile(index)}
                      className="absolute -top-2 -right-2 w-6 h-6 bg-red-500 text-white rounded-full flex items-center justify-center hover:bg-red-600 transition-colors shadow-sm"
                    >
                      <X className="w-4 h-4" />
                    </button>
                    <div className="flex flex-col items-center text-center">
                      <div className="w-12 h-12 bg-green-50 rounded-lg flex items-center justify-center mb-3">
                         <Minimize className="w-6 h-6 text-green-600" />
                      </div>
                      <p className="text-sm font-bold text-slate-700 truncate w-full px-2">
                        {file.name}
                      </p>
                      <p className="text-xs text-slate-400 mt-1">
                        {(file.size / 1024).toFixed(0)} KB
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </Layout>
  );
}

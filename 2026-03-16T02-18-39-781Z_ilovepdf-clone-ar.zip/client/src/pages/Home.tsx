import { Layout } from "@/components/Layout";
import { 
  FileStack, 
  Scissors, 
  Zap, 
  FileType, 
  FileImage, 
  ShieldCheck, 
  ArrowLeftRight,
  Stamp,
  Lock,
  RotateCw,
  Hash,
  RefreshCw,
  Maximize,
  Minimize
} from "lucide-react";
import { Link } from "wouter";

const tools = [
  {
    title: "دمج PDF",
    description: "اجمع ملفات PDF بالترتيب الذي تريده بأسهل طريقة ممكنة.",
    icon: <FileStack className="w-10 h-10 text-[#e5322d]" />,
    href: "/merge",
    color: "bg-red-50"
  },
  {
    title: "تقسيم PDF",
    description: "استخرج صفحة أو أكثر من ملف PDF أو قم بتحويل كل صفحة إلى ملف PDF مستقل.",
    icon: <Scissors className="w-10 h-10 text-[#e5322d]" />,
    href: "/split",
    color: "bg-red-50"
  },
  {
    title: "ضغط PDF",
    description: "قلل حجم ملف PDF الخاص بك مع الحفاظ على أفضل جودة ممكنة.",
    icon: <Zap className="w-10 h-10 text-[#e5322d]" />,
    href: "/compress",
    color: "bg-red-50"
  },
  {
    title: "PDF إلى Word",
    description: "حول ملفات PDF إلى مستندات Word بدقة متناهية.",
    icon: <FileType className="w-10 h-10 text-blue-500" />,
    href: "/pdf-to-word",
    color: "bg-blue-50"
  },
  {
    title: "PDF إلى PowerPoint",
    description: "حول ملفات PDF إلى عروض PowerPoint تقديمية قابلة للتعديل.",
    icon: <FileType className="w-10 h-10 text-orange-500" />,
    href: "/pdf-to-ppt",
    color: "bg-orange-50"
  },
  {
    title: "PDF إلى Excel",
    description: "استخرج البيانات من ملفات PDF إلى جداول Excel مباشرة.",
    icon: <FileType className="w-10 h-10 text-green-600" />,
    href: "/pdf-to-excel",
    color: "bg-green-50"
  },
  {
    title: "Word إلى PDF",
    description: "حول مستندات Word إلى ملفات PDF بنفس التنسيق الأصلي.",
    icon: <FileType className="w-10 h-10 text-blue-600" />,
    href: "/word-to-pdf",
    color: "bg-blue-50"
  },
  {
    title: "PowerPoint إلى PDF",
    description: "حول عروض PowerPoint إلى ملفات PDF بسهولة.",
    icon: <FileType className="w-10 h-10 text-orange-600" />,
    href: "/ppt-to-pdf",
    color: "bg-orange-50"
  },
  {
    title: "Excel إلى PDF",
    description: "اجعل جداول Excel الخاصة بك سهلة القراءة بتحويلها إلى PDF.",
    icon: <FileType className="w-10 h-10 text-green-700" />,
    href: "/excel-to-pdf",
    color: "bg-green-50"
  },
  {
    title: "تعديل PDF",
    description: "أضف نصاً أو صوراً أو أشكالاً أو تعليقات توضيحية لملف PDF.",
    icon: <FileType className="w-10 h-10 text-[#e5322d]" />,
    href: "/edit",
    color: "bg-red-50"
  },
  {
    title: "محول صيغ الصور",
    description: "حول صورك بين الصيغ المختلفة (JPG, PNG, WebP) بسرعة وبجودة عالية.",
    icon: <RefreshCw className="w-10 h-10 text-yellow-500" />,
    href: "/image-converter",
    color: "bg-yellow-50"
  },
  {
    title: "JPG إلى PDF",
    description: "حول صور JPG و PNG إلى ملف PDF بسهولة في ثوانٍ.",
    icon: <FileImage className="w-10 h-10 text-yellow-600" />,
    href: "/jpg-to-pdf",
    color: "bg-yellow-50"
  },
  {
    title: "تغيير حجم الصور",
    description: "حدد العرض والارتفاع الجديد لصورك بسهولة مع الحفاظ على الجودة.",
    icon: <Maximize className="w-10 h-10 text-blue-600" />,
    href: "/image-resize",
    color: "bg-blue-50"
  },
  {
    title: "ضغط الصور",
    description: "قلل حجم ملفات صورك مع الحفاظ على أفضل جودة بصرية ممكنة.",
    icon: <Minimize className="w-10 h-10 text-green-600" />,
    href: "/image-compress",
    color: "bg-green-50"
  },
  {
    title: "ترقيم الصفحات",
    description: "أضف أرقام الصفحات لملف PDF الخاص بك بسهولة.",
    icon: <Hash className="w-10 h-10 text-slate-600" />,
    href: "/page-numbers",
    color: "bg-slate-50"
  },
  {
    title: "علامة مائية",
    description: "أضف صورة أو نصاً كعلامة مائية فوق ملف PDF الخاص بك.",
    icon: <Stamp className="w-10 h-10 text-slate-600" />,
    href: "/watermark",
    color: "bg-slate-50"
  },
  {
    title: "تدوير PDF",
    description: "قم بتدوير ملفات PDF الخاصة بك كما تريد.",
    icon: <RotateCw className="w-10 h-10 text-slate-600" />,
    href: "/rotate",
    color: "bg-slate-50"
  },
  {
    title: "حماية PDF",
    description: "احمِ ملفات PDF بكلمة مرور وتشفير قوي.",
    icon: <Lock className="w-10 h-10 text-slate-700" />,
    href: "/protect",
    color: "bg-slate-100"
  }
];

export default function Home() {
  return (
    <Layout>
      <section className="bg-white py-16 md:py-24">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-5xl font-black text-slate-800 mb-6 leading-tight">
            كل أدوات PDF التي تحتاجها في مكان واحد
          </h1>
          <p className="text-xl text-slate-600 max-w-3xl mx-auto leading-relaxed font-medium">
            PDFعربي هو خدمتك المجانية وسهلة الاستخدام عبر الإنترنت للتعامل مع ملفات PDF. 
            ادمج، قسّم، اضغط، حول، عدل وأمن ملفات PDF بنقرات قليلة.
          </p>
        </div>
      </section>

      <section className="py-12 bg-[#f3f3f3]">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {tools.map((tool, index) => (
              <Link key={index} href={tool.href}>
                <div className="bg-white p-8 rounded-xl border border-gray-200 shadow-sm hover:shadow-md hover:border-[#e5322d]/30 transition-all cursor-pointer group flex flex-col h-full">
                  <div className="mb-6 flex justify-center">
                    {tool.icon}
                  </div>
                  <h3 className="text-xl font-black text-slate-800 mb-3 text-center">
                    {tool.title}
                  </h3>
                  <p className="text-slate-500 text-sm leading-relaxed text-center font-medium">
                    {tool.description}
                  </p>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 bg-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-black text-slate-800 mb-8">لماذا تختار PDFعربي؟</h2>
          <div className="grid md:grid-cols-3 gap-12">
            <div>
              <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <Zap className="w-8 h-8 text-[#e5322d]" />
              </div>
              <h4 className="text-xl font-bold text-slate-800 mb-4">سرعة فائقة</h4>
              <p className="text-slate-500 leading-relaxed font-medium">معالجة ملفاتك تتم في ثوانٍ معدودة بفضل خوادمنا القوية.</p>
            </div>
            <div>
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <ShieldCheck className="w-8 h-8 text-blue-600" />
              </div>
              <h4 className="text-xl font-bold text-slate-800 mb-4">أمان تام</h4>
              <p className="text-slate-500 leading-relaxed font-medium">يتم حذف جميع ملفاتك تلقائياً من خوادمنا بعد ساعة واحدة من المعالجة.</p>
            </div>
            <div>
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <ArrowLeftRight className="w-8 h-8 text-green-600" />
              </div>
              <h4 className="text-xl font-bold text-slate-800 mb-4">جودة عالية</h4>
              <p className="text-slate-500 leading-relaxed font-medium">نضمن لك أفضل جودة ممكنة للملفات الناتجة مع الحفاظ على التنسيق.</p>
            </div>
          </div>
        </div>
      </section>
    </Layout>
  );
}

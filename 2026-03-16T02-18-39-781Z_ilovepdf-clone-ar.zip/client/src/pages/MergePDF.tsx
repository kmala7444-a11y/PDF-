import { PDFToolPage } from "@/components/PDFToolPage";
import { FileStack } from "lucide-react";
import { PDFDocument } from "pdf-lib";
import { useLanguage } from "@/contexts/LanguageContext";

export default function MergePDF() {
  const { t } = useLanguage();
  const handleMerge = async (files: File[]) => {
    if (files.length < 2) {
      throw new Error("يرجى اختيار ملفين على الأقل للدمج.");
    }

    const mergedPdf = await PDFDocument.create();

    for (const file of files) {
      const arrayBuffer = await file.arrayBuffer();
      const pdf = await PDFDocument.load(arrayBuffer);
      const copiedPages = await mergedPdf.copyPages(pdf, pdf.getPageIndices());
      copiedPages.forEach((page) => mergedPdf.addPage(page));
    }

    const pdfBytes = await mergedPdf.save();
    const blob = new Blob([pdfBytes as any], { type: "application/pdf" });
    const url = URL.createObjectURL(blob);
    
    const a = document.createElement("a");
    a.href = url;
    a.download = "merged.pdf";
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <PDFToolPage
      title={t('tool_merge_title')}
      description={t('tool_merge_desc')}
      actionLabel={t('btn_merge')}
      onProcess={handleMerge}
      icon={<FileStack className="w-10 h-10 text-[#e5322d]" />}
    />
  );
}

import { useState, useCallback } from "react";
import { Layout } from "@/components/Layout";
import { Button } from "@/components/ui/button";
import { Upload, X, Maximize, AlertCircle, Loader2, Settings2 } from "lucide-react";
import { useDropzone } from "react-dropzone";
import { toast } from "sonner";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useLanguage } from "@/contexts/LanguageContext";

export default function ImageResize() {
  const { t } = useLanguage();
  const [files, setFiles] = useState<File[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [width, setWidth] = useState<number>(800);
  const [height, setHeight] = useState<number>(600);
  const [maintainAspectRatio, setMaintainAspectRatio] = useState(true);

  const onDrop = useCallback((acceptedFiles: File[]) => {
    const imageFiles = acceptedFiles.filter(file => file.type.startsWith("image/"));
    if (imageFiles.length < acceptedFiles.length) {
      toast.error(t('error_img_only'));
    }
    setFiles(prev => [...prev, ...imageFiles]);
  }, [t]);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: { 'image/*': [] },
    multiple: true
  });

  const removeFile = (index: number) => {
    setFiles(prev => prev.filter((_, i) => i !== index));
  };

  const resizeImage = (file: File, targetWidth: number, targetHeight: number): Promise<Blob> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        const img = new Image();
        img.onload = () => {
          const canvas = document.createElement('canvas');
          canvas.width = targetWidth;
          canvas.height = targetHeight;
          const ctx = canvas.getContext('2d');
          if (!ctx) return reject(new Error("Failed to get canvas context"));
          
          ctx.imageSmoothingEnabled = true;
          ctx.imageSmoothingQuality = 'high';
          ctx.drawImage(img, 0, 0, targetWidth, targetHeight);
          
          canvas.toBlob((blob) => {
            if (blob) resolve(blob);
            else reject(new Error("Resizing failed"));
          }, file.type);
        };
        img.onerror = reject;
        img.src = e.target?.result as string;
      };
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  };

  const handleProcess = async () => {
    if (files.length === 0) return;
    setIsProcessing(true);
    try {
      for (const file of files) {
        const resizedBlob = await resizeImage(file, width, height);
        const url = URL.createObjectURL(resizedBlob);
        const a = document.createElement("a");
        a.href = url;
        a.download = `resized_${file.name}`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
      }
      toast.success(t('success_msg'));
    } catch (error) {
      toast.error(t('error_msg'));
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <Layout>
      <div className="bg-white border-b border-gray-200">
        <div className="container mx-auto px-4 py-12 text-center">
          <div className="inline-flex p-4 bg-blue-50 rounded-2xl mb-6">
            <Maximize className="w-10 h-10 text-blue-600" />
          </div>
          <h1 className="text-3xl font-black text-slate-800 mb-4">{t('tool_resize_title')}</h1>
          <p className="text-slate-500 max-w-2xl mx-auto font-medium">{t('tool_resize_desc')}</p>
        </div>
      </div>

      <div className="py-12 bg-[#f3f3f3] min-h-[500px]">
        <div className="container mx-auto px-4 max-w-4xl">
          {files.length === 0 ? (
            <div 
              {...getRootProps()} 
              className={`
                border-4 border-dashed rounded-3xl p-16 text-center cursor-pointer transition-all
                ${isDragActive ? 'border-blue-500 bg-blue-50' : 'border-gray-300 bg-white hover:border-blue-500/50 hover:bg-blue-50/10'}
              `}
            >
              <input {...getInputProps()} />
              <div className="flex flex-col items-center">
                <div className="w-20 h-20 bg-blue-50 rounded-full flex items-center justify-center mb-6">
                  <Upload className="w-10 h-10 text-blue-600" />
                </div>
                <h3 className="text-2xl font-black text-slate-800 mb-3">{t('choose_images')}</h3>
                <p className="text-slate-500 font-medium mb-8">{t('drop_images')}</p>
                <Button size="lg" className="bg-blue-600 hover:bg-blue-700 text-white px-12 py-7 text-xl font-black rounded-xl">
                  {t('choose_images')}
                </Button>
              </div>
            </div>
          ) : (
            <div className="space-y-6">
              <div className="bg-white p-8 rounded-2xl border border-gray-200 shadow-sm">
                <div className="flex items-center gap-2 mb-6 text-blue-600 font-black">
                  <Settings2 className="w-5 h-5" />
                  <span>{t('resize_settings')}</span>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  <div className="space-y-3">
                    <Label className="text-slate-700 font-bold">{t('width_px')}</Label>
                    <Input 
                      type="number" 
                      value={width} 
                      onChange={(e) => setWidth(parseInt(e.target.value) || 0)}
                      className="h-12 text-lg font-bold"
                    />
                  </div>
                  <div className="space-y-3">
                    <Label className="text-slate-700 font-bold">{t('height_px')}</Label>
                    <Input 
                      type="number" 
                      value={height} 
                      onChange={(e) => setHeight(parseInt(e.target.value) || 0)}
                      className="h-12 text-lg font-bold"
                    />
                  </div>
                </div>
                
                <div className="flex justify-center mt-10">
                  <Button 
                    onClick={handleProcess}
                    disabled={isProcessing}
                    size="lg" 
                    className="bg-blue-600 hover:bg-blue-700 text-white px-20 py-8 text-2xl font-black rounded-2xl shadow-xl shadow-blue-500/20"
                  >
                    {isProcessing ? <Loader2 className="animate-spin ml-2" /> : null}
                    {isProcessing ? t('processing') : t('btn_resize')}
                  </Button>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                {files.map((file, index) => (
                  <div key={index} className="bg-white p-4 rounded-xl border border-gray-200 shadow-sm relative group">
                    <button 
                      onClick={() => removeFile(index)}
                      className="absolute -top-2 -right-2 w-6 h-6 bg-red-500 text-white rounded-full flex items-center justify-center hover:bg-red-600 transition-colors shadow-sm"
                    >
                      <X className="w-4 h-4" />
                    </button>
                    <div className="flex flex-col items-center text-center">
                      <div className="w-12 h-12 bg-blue-50 rounded-lg flex items-center justify-center mb-3">
                         <Maximize className="w-6 h-6 text-blue-600" />
                      </div>
                      <p className="text-sm font-bold text-slate-700 truncate w-full px-2">
                        {file.name}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </Layout>
  );
}

import { useState, useCallback } from "react";
import { Layout } from "@/components/Layout";
import { Button } from "@/components/ui/button";
import { Upload, X, FileImage, AlertCircle, Loader2, RefreshCw } from "lucide-react";
import { useDropzone } from "react-dropzone";
import { toast } from "sonner";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useLanguage } from "@/contexts/LanguageContext";

export default function ImageConverter() {
  const { t } = useLanguage();
  const [files, setFiles] = useState<File[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [targetFormat, setTargetFormat] = useState("image/png");

  const onDrop = useCallback((acceptedFiles: File[]) => {
    const imageFiles = acceptedFiles.filter(file => file.type.startsWith("image/"));
    if (imageFiles.length < acceptedFiles.length) {
      toast.error(t('error_img_only'));
    }
    setFiles(prev => [...prev, ...imageFiles]);
  }, [t]);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: { 'image/*': [] },
    multiple: true
  });

  const removeFile = (index: number) => {
    setFiles(prev => prev.filter((_, i) => i !== index));
  };

  const convertImage = (file: File, format: string): Promise<Blob> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        const img = new Image();
        img.onload = () => {
          const canvas = document.createElement('canvas');
          canvas.width = img.width;
          canvas.height = img.height;
          const ctx = canvas.getContext('2d');
          if (!ctx) return reject(new Error("Failed to get canvas context"));
          ctx.drawImage(img, 0, 0);
          canvas.toBlob((blob) => {
            if (blob) resolve(blob);
            else reject(new Error("Conversion failed"));
          }, format);
        };
        img.onerror = reject;
        img.src = e.target?.result as string;
      };
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  };

  const handleProcess = async () => {
    if (files.length === 0) return;
    setIsProcessing(true);
    try {
      for (const file of files) {
        const convertedBlob = await convertImage(file, targetFormat);
        const ext = targetFormat.split('/')[1];
        const url = URL.createObjectURL(convertedBlob);
        const a = document.createElement("a");
        a.href = url;
        a.download = `${file.name.split('.')[0]}.${ext}`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
      }
      toast.success(t('success_msg'));
    } catch (error) {
      toast.error(t('error_msg'));
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <Layout>
      <div className="bg-white border-b border-gray-200">
        <div className="container mx-auto px-4 py-12 text-center">
          <div className="inline-flex p-4 bg-yellow-50 rounded-2xl mb-6">
            <RefreshCw className="w-10 h-10 text-yellow-600" />
          </div>
          <h1 className="text-3xl font-black text-slate-800 mb-4">{t('tool_converter_title')}</h1>
          <p className="text-slate-500 max-w-2xl mx-auto font-medium">{t('tool_converter_desc')}</p>
        </div>
      </div>

      <div className="py-12 bg-[#f3f3f3] min-h-[500px]">
        <div className="container mx-auto px-4 max-w-4xl">
          {files.length === 0 ? (
            <div 
              {...getRootProps()} 
              className={`
                border-4 border-dashed rounded-3xl p-16 text-center cursor-pointer transition-all
                ${isDragActive ? 'border-yellow-500 bg-yellow-50' : 'border-gray-300 bg-white hover:border-yellow-500/50 hover:bg-yellow-50/10'}
              `}
            >
              <input {...getInputProps()} />
              <div className="flex flex-col items-center">
                <div className="w-20 h-20 bg-yellow-50 rounded-full flex items-center justify-center mb-6">
                  <Upload className="w-10 h-10 text-yellow-600" />
                </div>
                <h3 className="text-2xl font-black text-slate-800 mb-3">{t('choose_images')}</h3>
                <p className="text-slate-500 font-medium mb-8">{t('drop_images')}</p>
                <Button size="lg" className="bg-yellow-600 hover:bg-yellow-700 text-white px-12 py-7 text-xl font-black rounded-xl">
                  {t('choose_images')}
                </Button>
              </div>
            </div>
          ) : (
            <div className="space-y-6">
              <div className="bg-white p-6 rounded-2xl border border-gray-200 flex flex-col md:flex-row items-center justify-between gap-6">
                <div className="flex items-center gap-4">
                  <span className="font-bold text-slate-700">{t('convert_to')}</span>
                  <Select value={targetFormat} onValueChange={setTargetFormat}>
                    <SelectTrigger className="w-[180px] font-bold">
                      <SelectValue placeholder={t('choose_format') || "JPG"} />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="image/jpeg">JPG</SelectItem>
                      <SelectItem value="image/png">PNG</SelectItem>
                      <SelectItem value="image/webp">WebP</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <Button 
                  onClick={handleProcess}
                  disabled={isProcessing}
                  size="lg" 
                  className="bg-yellow-600 hover:bg-yellow-700 text-white px-12 font-black rounded-xl"
                >
                  {isProcessing ? <Loader2 className="animate-spin" /> : t('btn_start_convert')}
                </Button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                {files.map((file, index) => (
                  <div key={index} className="bg-white p-4 rounded-xl border border-gray-200 shadow-sm relative group">
                    <button 
                      onClick={() => removeFile(index)}
                      className="absolute -top-2 -right-2 w-6 h-6 bg-red-500 text-white rounded-full flex items-center justify-center hover:bg-red-600 transition-colors shadow-sm"
                    >
                      <X className="w-4 h-4" />
                    </button>
                    <div className="flex flex-col items-center text-center">
                      <FileImage className="w-12 h-12 text-yellow-600 mb-3" />
                      <p className="text-sm font-bold text-slate-700 truncate w-full px-2">
                        {file.name}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </Layout>
  );
}

import { Layout } from "@/components/Layout";
import { Zap, ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";

export default function ToolComingSoon() {
  return (
    <Layout>
      <div className="container mx-auto px-4 py-32 text-center">
        <div className="w-24 h-24 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-8 animate-pulse">
          <Zap className="w-12 h-12 text-[#e5322d]" />
        </div>
        <h1 className="text-4xl font-black text-slate-800 mb-4">هذه الأداة قادمة قريباً!</h1>
        <p className="text-xl text-slate-500 mb-12 max-w-lg mx-auto leading-relaxed">
          نحن نعمل حالياً على تطوير هذه الميزة لتوفير أفضل تجربة ممكنة لمستخدمينا. شكراً لصبركم!
        </p>
        <Link href="/">
          <Button size="lg" className="bg-[#e5322d] hover:bg-[#c42a25] text-white px-8 py-6 text-lg font-bold">
            <ArrowLeft className="ml-2 w-5 h-5" />
            العودة للرئيسية
          </Button>
        </Link>
      </div>
    </Layout>
  );
}

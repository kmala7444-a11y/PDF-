import { PDFToolPage } from "@/components/PDFToolPage";
import { Scissors } from "lucide-react";
import { PDFDocument } from "pdf-lib";
import JSZip from "jszip";
import { useLanguage } from "@/contexts/LanguageContext";

export default function SplitPDF() {
  const { t } = useLanguage();
  const handleSplit = async (files: File[]) => {
    if (files.length === 0) return;
    
    const zip = new JSZip();
    
    for (const file of files) {
      const arrayBuffer = await file.arrayBuffer();
      const pdf = await PDFDocument.load(arrayBuffer);
      const pageCount = pdf.getPageCount();
      
      for (let i = 0; i < pageCount; i++) {
        const singlePagePdf = await PDFDocument.create();
        const [copiedPage] = await singlePagePdf.copyPages(pdf, [i]);
        singlePagePdf.addPage(copiedPage);
        const pdfBytes = await singlePagePdf.save();
        zip.file(`${file.name.replace('.pdf', '')}_page_${i+1}.pdf`, pdfBytes);
      }
    }
    
    const zipBlob = await zip.generateAsync({ type: "blob" });
    const url = URL.createObjectURL(zipBlob);
    
    const a = document.createElement("a");
    a.href = url;
    a.download = "split_pages.zip";
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <PDFToolPage
      title={t('tool_split_title')}
      description={t('tool_split_desc')}
      actionLabel={t('btn_split')}
      onProcess={handleSplit}
      icon={<Scissors className="w-10 h-10 text-[#e5322d]" />}
    />
  );
}

import { ReactNode } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { FileText, Menu, User, Globe } from "lucide-react";
import { useLanguage } from "@/contexts/LanguageContext";

export function Layout({ children }: { children: ReactNode }) {
  const { lang, setLang, t, dir } = useLanguage();

  return (
    <div className={`min-h-screen bg-[#f3f3f3] flex flex-col ${lang === 'ar' ? "font-['Cairo']" : "font-sans"}`} dir={dir}>
      <header className="bg-white border-b border-gray-200 sticky top-0 z-50">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-8">
            <Link href="/" className="flex items-center gap-2">
              <FileText className="w-8 h-8 text-[#e5322d]" />
              <span className="text-2xl font-black text-slate-800 tracking-tight">PDF<span className="text-[#e5322d]">{lang === 'ar' ? 'عربي' : 'AR'}</span></span>
            </Link>
            
            <nav className="hidden md:flex items-center gap-6">
              <Link href="/merge" className="text-sm font-bold text-slate-600 hover:text-[#e5322d] transition-colors uppercase">{t('nav_merge')}</Link>
              <Link href="/split" className="text-sm font-bold text-slate-600 hover:text-[#e5322d] transition-colors uppercase">{t('nav_split')}</Link>
              <Link href="/image-compress" className="text-sm font-bold text-slate-600 hover:text-[#e5322d] transition-colors uppercase">{t('nav_compress')}</Link>
              <div className="relative group">
                <button className="text-sm font-bold text-slate-600 hover:text-[#e5322d] transition-colors uppercase flex items-center gap-1">
                  {t('nav_all_tools')}
                </button>
              </div>
            </nav>
          </div>

          <div className="flex items-center gap-4">
            <Button 
              variant="ghost" 
              size="sm" 
              className="font-bold flex items-center gap-1 text-slate-600"
              onClick={() => setLang(lang === 'ar' ? 'en' : 'ar')}
            >
              <Globe className="w-4 h-4" />
              {lang === 'ar' ? 'English' : 'العربية'}
            </Button>
            
            <Button variant="ghost" className="hidden md:flex items-center gap-2 font-bold text-slate-700">
              <User className="w-4 h-4" />
              {t('nav_login')}
            </Button>
            <Button className="bg-[#e5322d] hover:bg-[#c42a25] text-white font-bold px-6">
              {t('nav_signup')}
            </Button>
            <Button variant="ghost" size="icon" className="md:hidden">
              <Menu className="w-6 h-6" />
            </Button>
          </div>
        </div>
      </header>

      <main className="flex-1">
        {children}
      </main>

      <footer className="bg-white border-t border-gray-200 py-12">
        <div className="container mx-auto px-4 text-center">
          <p className="text-slate-500 font-medium">© 2026 PDF{lang === 'ar' ? 'عربي' : 'AR'} - {t('footer_rights')}</p>
          <div className="mt-4 flex justify-center gap-6">
            <a href="#" className="text-slate-400 hover:text-[#e5322d]">{t('footer_terms')}</a>
            <a href="#" className="text-slate-400 hover:text-[#e5322d]">{t('footer_privacy')}</a>
            <a href="#" className="text-slate-400 hover:text-[#e5322d]">{t('footer_contact')}</a>
          </div>
        </div>
      </footer>
    </div>
  );
}

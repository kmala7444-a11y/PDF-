import { useState, useCallback } from "react";
import { Layout } from "@/components/Layout";
import { Button } from "@/components/ui/button";
import { Upload, X, File, AlertCircle, Loader2 } from "lucide-react";
import { useDropzone } from "react-dropzone";
import { toast } from "sonner";
import { useLanguage } from "@/contexts/LanguageContext";

interface PDFToolPageProps {
  title: string;
  description: string;
  actionLabel: string;
  onProcess: (files: File[]) => Promise<void>;
  icon: React.ReactNode;
  isImage?: boolean;
}

export function PDFToolPage({ title, description, actionLabel, onProcess, icon, isImage = false }: PDFToolPageProps) {
  const [files, setFiles] = useState<File[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const { t } = useLanguage();

  const onDrop = useCallback((acceptedFiles: File[]) => {
    const validFiles = isImage 
      ? acceptedFiles.filter(file => file.type.startsWith("image/"))
      : acceptedFiles.filter(file => file.type === "application/pdf");
    
    if (validFiles.length < acceptedFiles.length) {
      toast.error(isImage ? t('error_img_only') : t('error_pdf_only'));
    }
    setFiles(prev => [...prev, ...validFiles]);
  }, [isImage, t]);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: isImage ? { 'image/*': [] } : { 'application/pdf': ['.pdf'] },
    multiple: true
  });

  const removeFile = (index: number) => {
    setFiles(prev => prev.filter((_, i) => i !== index));
  };

  const handleProcess = async () => {
    if (files.length === 0) return;
    setIsProcessing(true);
    try {
      await onProcess(files);
      toast.success(t('success_msg'));
    } catch (error) {
      toast.error(t('error_msg'));
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <Layout>
      <div className="bg-white border-b border-gray-200">
        <div className="container mx-auto px-4 py-12 text-center">
          <div className="inline-flex p-4 bg-red-50 rounded-2xl mb-6">
            {icon}
          </div>
          <h1 className="text-3xl font-black text-slate-800 mb-4">{title}</h1>
          <p className="text-slate-500 max-w-2xl mx-auto font-medium">{description}</p>
        </div>
      </div>

      <div className="py-12 bg-[#f3f3f3] min-h-[500px]">
        <div className="container mx-auto px-4 max-w-4xl">
          {files.length === 0 ? (
            <div 
              {...getRootProps()} 
              className={`
                border-4 border-dashed rounded-3xl p-16 text-center cursor-pointer transition-all
                ${isDragActive ? 'border-[#e5322d] bg-red-50' : 'border-gray-300 bg-white hover:border-[#e5322d]/50 hover:bg-red-50/10'}
              `}
            >
              <input {...getInputProps()} />
              <div className="flex flex-col items-center">
                <div className="w-20 h-20 bg-red-50 rounded-full flex items-center justify-center mb-6">
                  <Upload className="w-10 h-10 text-[#e5322d]" />
                </div>
                <h3 className="text-2xl font-black text-slate-800 mb-3">{isImage ? t('choose_images') : t('choose_files')}</h3>
                <p className="text-slate-500 font-medium mb-8">{isImage ? t('drop_images') : t('drop_files')}</p>
                <Button size="lg" className="bg-[#e5322d] hover:bg-[#c42a25] text-white px-12 py-7 text-xl font-black rounded-xl">
                  {isImage ? t('choose_images') : t('choose_files')}
                </Button>
              </div>
            </div>
          ) : (
            <div className="space-y-6">
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                {files.map((file, index) => (
                  <div key={index} className="bg-white p-4 rounded-xl border border-gray-200 shadow-sm relative group">
                    <button 
                      onClick={() => removeFile(index)}
                      className="absolute -top-2 -right-2 w-6 h-6 bg-red-500 text-white rounded-full flex items-center justify-center hover:bg-red-600 transition-colors shadow-sm"
                    >
                      <X className="w-4 h-4" />
                    </button>
                    <div className="flex flex-col items-center text-center">
                      <File className="w-12 h-12 text-[#e5322d] mb-3" />
                      <p className="text-sm font-bold text-slate-700 truncate w-full px-2">
                        {file.name}
                      </p>
                      <p className="text-xs text-slate-400 mt-1">
                        {(file.size / 1024 / 1024).toFixed(2)} MB
                      </p>
                    </div>
                  </div>
                ))}
                
                <div 
                  {...getRootProps()} 
                  className="bg-white/50 border-2 border-dashed border-gray-300 rounded-xl p-4 flex flex-col items-center justify-center cursor-pointer hover:border-[#e5322d] hover:bg-red-50/20 transition-all min-h-[140px]"
                >
                  <input {...getInputProps()} />
                  <Upload className="w-6 h-6 text-slate-400 mb-2" />
                  <span className="text-sm font-bold text-slate-500">{t('add_more')}</span>
                </div>
              </div>

              <div className="flex justify-center pt-8">
                <Button 
                  onClick={handleProcess}
                  disabled={isProcessing}
                  size="lg" 
                  className="bg-[#e5322d] hover:bg-[#c42a25] text-white px-16 py-8 text-2xl font-black rounded-2xl shadow-xl shadow-red-500/20 transition-all hover:scale-105 active:scale-95 flex items-center gap-4"
                >
                  {isProcessing ? (
                    <>
                      <Loader2 className="w-6 h-6 animate-spin" />
                      {t('processing')}
                    </>
                  ) : (
                    actionLabel
                  )}
                </Button>
              </div>
            </div>
          )}
          
          <div className="mt-16 bg-blue-50 border border-blue-100 p-6 rounded-2xl flex gap-4">
            <AlertCircle className="w-6 h-6 text-blue-500 shrink-0" />
            <div>
              <h4 className="font-bold text-blue-800 mb-1">{t('help_title')}</h4>
              <p className="text-blue-600 text-sm font-medium">{t('privacy_note')}</p>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}

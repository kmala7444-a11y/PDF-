import React, { createContext, useContext, useState, ReactNode, useEffect } from "react";

type Language = "ar" | "en";

interface Translations {
  [key: string]: {
    ar: string;
    en: string;
  };
}

const translations: Translations = {
  // Navigation & Layout
  nav_merge: { ar: "دمج PDF", en: "Merge PDF" },
  nav_split: { ar: "تقسيم PDF", en: "Split PDF" },
  nav_compress: { ar: "ضغط PDF", en: "Compress PDF" },
  nav_all_tools: { ar: "كل أدوات PDF", en: "All PDF Tools" },
  nav_login: { ar: "تسجيل الدخول", en: "Login" },
  nav_signup: { ar: "إنشاء حساب", en: "Sign Up" },
  footer_rights: { ar: "جميع الحقوق محفوظة", en: "All Rights Reserved" },
  footer_terms: { ar: "الشروط والأحكام", en: "Terms & Conditions" },
  footer_privacy: { ar: "سياسة الخصوصية", en: "Privacy Policy" },
  footer_contact: { ar: "تواصل معنا", en: "Contact Us" },

  // Home Page
  hero_title: { ar: "كل أدوات PDF التي تحتاجها في مكان واحد", en: "Every PDF tool you need in one place" },
  hero_desc: { ar: "PDFعربي هو خدمتك المجانية وسهلة الاستخدام عبر الإنترنت للتعامل مع ملفات PDF. ادمج، قسّم، اضغط، حول، عدل وأمن ملفات PDF بنقرات قليلة.", en: "PDFعربي is your free and easy-to-use online service to handle PDF files. Merge, split, compress, convert, edit and protect PDF files with just a few clicks." },
  why_choose: { ar: "لماذا تختار PDFعربي؟", en: "Why Choose PDFعربي?" },
  fast_title: { ar: "سرعة فائقة", en: "Super Fast" },
  fast_desc: { ar: "معالجة ملفاتك تتم في ثوانٍ معدودة بفضل خوادمنا القوية.", en: "Processing your files takes just seconds thanks to our powerful servers." },
  secure_title: { ar: "أمان تام", en: "Total Security" },
  secure_desc: { ar: "يتم حذف جميع ملفاتك تلقائياً من خوادمنا بعد ساعة واحدة من المعالجة.", en: "All your files are automatically deleted from our servers one hour after processing." },
  quality_title: { ar: "جودة عالية", en: "High Quality" },
  quality_desc: { ar: "نضمن لك أفضل جودة ممكنة للملفات الناتجة مع الحفاظ على التنسيق.", en: "We guarantee the best possible quality for the resulting files while maintaining the formatting." },

  // Tools Home
  tool_merge_title: { ar: "دمج PDF", en: "Merge PDF" },
  tool_merge_desc: { ar: "اجمع ملفات PDF بالترتيب الذي تريده بأسهل طريقة ممكنة.", en: "Combine PDF files in the order you want in the easiest way possible." },
  tool_split_title: { ar: "تقسيم PDF", en: "Split PDF" },
  tool_split_desc: { ar: "استخرج صفحة أو أكثر من ملف PDF أو قم بتحويل كل صفحة إلى ملف PDF مستقل.", en: "Extract one or more pages from a PDF or convert each page to an independent PDF file." },
  tool_compress_title: { ar: "ضغط الصور", en: "Compress Images" },
  tool_compress_desc: { ar: "قلل حجم ملفات صورك مع الحفاظ على أفضل جودة بصرية ممكنة.", en: "Reduce the size of your image files while maintaining the best possible visual quality." },
  tool_converter_title: { ar: "محول صيغ الصور", en: "Image Converter" },
  tool_converter_desc: { ar: "حول صورك بين الصيغ المختلفة (JPG, PNG, WebP) بسرعة وبجودة عالية.", en: "Convert your images between different formats (JPG, PNG, WebP) quickly and with high quality." },
  tool_resize_title: { ar: "تغيير حجم الصور", en: "Resize Images" },
  tool_resize_desc: { ar: "حدد العرض والارتفاع الجديد لصورك بسهولة مع الحفاظ على الجودة.", en: "Set the new width and height for your images easily while maintaining quality." },
  tool_jpg2pdf_title: { ar: "JPG إلى PDF", en: "JPG to PDF" },
  tool_jpg2pdf_desc: { ar: "حول صور JPG و PNG إلى ملف PDF بسهولة في ثوانٍ.", en: "Convert JPG and PNG images to a PDF file easily in seconds." },

  // Generic Tool UI
  choose_files: { ar: "اختر ملفات PDF", en: "Choose PDF files" },
  choose_images: { ar: "اختر الصور", en: "Choose images" },
  drop_files: { ar: "أو اسحب وأسقط الملفات هنا", en: "or drag and drop files here" },
  drop_images: { ar: "أو اسحب وأسقط الصور هنا", en: "or drag and drop images here" },
  add_more: { ar: "إضافة المزيد", en: "Add more" },
  processing: { ar: "جاري المعالجة...", en: "Processing..." },
  help_title: { ar: "تحتاج مساعدة؟", en: "Need help?" },
  privacy_note: { ar: "نحن نحمي خصوصيتك. يتم حذف ملفاتك تلقائياً من خوادمنا بعد ساعة واحدة.", en: "We protect your privacy. Your files are automatically deleted from our servers after one hour." },
  success_msg: { ar: "تمت العملية بنجاح!", en: "Operation successful!" },
  error_msg: { ar: "حدث خطأ أثناء معالجة الملفات.", en: "An error occurred while processing files." },
  error_pdf_only: { ar: "يرجى اختيار ملفات PDF فقط.", en: "Please select PDF files only." },
  error_img_only: { ar: "يرجى اختيار ملفات صور فقط.", en: "Please select image files only." },

  // Specific Tool Actions
  btn_merge: { ar: "دمج ملفات PDF", en: "Merge PDF files" },
  btn_split: { ar: "تقسيم ملفات PDF", en: "Split PDF files" },
  btn_convert: { ar: "تحويل إلى PDF", en: "Convert to PDF" },
  btn_start_convert: { ar: "بدء التحويل الآن", en: "Start Converting Now" },
  btn_resize: { ar: "تغيير الحجم والتحميل", en: "Resize and Download" },
  btn_start_compress: { ar: "بدء الضغط الآن", en: "Start Compressing Now" },

  // Tool Settings
  convert_to: { ar: "تحويل إلى:", en: "Convert to:" },
  resize_settings: { ar: "إعدادات الحجم الجديد", en: "New Size Settings" },
  width_px: { ar: "العرض (بكسل)", en: "Width (px)" },
  height_px: { ar: "الارتفاع (بكسل)", en: "Height (px)" },
  quality_level: { ar: "مستوى الجودة:", en: "Quality level:" },
  high_quality: { ar: "جودة عالية", en: "High Quality" },
  good_balance: { ar: "توازن جيد", en: "Good Balance" },
  high_compression: { ar: "ضغط عالي", en: "High Compression" },
};

interface LanguageContextType {
  lang: Language;
  setLang: (lang: Language) => void;
  t: (key: string) => string;
  dir: "rtl" | "ltr";
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [lang, setLang] = useState<Language>("ar");

  useEffect(() => {
    document.documentElement.dir = lang === "ar" ? "rtl" : "ltr";
    document.documentElement.lang = lang;
  }, [lang]);

  const t = (key: string) => {
    return translations[key]?.[lang] || key;
  };

  const dir = lang === "ar" ? "rtl" : "ltr";

  return (
    <LanguageContext.Provider value={{ lang, setLang, t, dir }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error("useLanguage must be used within a LanguageProvider");
  }
  return context;
}

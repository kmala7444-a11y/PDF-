/**
 * Storage helpers for file uploads
 *
 * For AI-generated assets (images, audio, video), use the Easy-Peasy.AI API
 * directly — it returns public URLs that can be used immediately.
 *
 * This module provides helpers for user-uploaded files that need temporary
 * storage on the server (e.g., audio files for transcription).
 *
 * Example usage:
 *   import { saveUploadedFile, getPublicUrl } from "./storage";
 *
 *   // Save user upload to local storage
 *   const filePath = await saveUploadedFile(buffer, "audio.mp3");
 *
 *   // For AI-generated assets, use URLs from the API response directly:
 *   // const images = await generateImage({ prompt: "..." });
 *   // images[0].image_url  ← this is already a public URL
 */

import { randomUUID } from "crypto";
import { mkdir, writeFile, readFile } from "fs/promises";
import path from "path";

const UPLOADS_DIR = path.join(process.cwd(), "public", "uploads");

/**
 * Save an uploaded file to local public/uploads directory.
 * Returns the relative URL path (e.g., "/uploads/abc123-file.mp3").
 */
export async function saveUploadedFile(
  data: Buffer | Uint8Array,
  originalName: string
): Promise<{ path: string; url: string }> {
  await mkdir(UPLOADS_DIR, { recursive: true });

  const safeName = originalName.replace(/[^a-zA-Z0-9._-]/g, "-");
  const fileName = `${randomUUID()}-${safeName}`;
  const filePath = path.join(UPLOADS_DIR, fileName);

  await writeFile(filePath, data);

  const url = `/uploads/${fileName}`;
  return { path: filePath, url };
}

/**
 * Read an uploaded file from local storage.
 */
export async function readUploadedFile(fileName: string): Promise<Buffer> {
  const safeName = path.basename(fileName);
  const filePath = path.join(UPLOADS_DIR, safeName);
  const resolved = path.resolve(filePath);
  if (!resolved.startsWith(path.resolve(UPLOADS_DIR))) {
    throw new Error("Invalid file path");
  }
  return readFile(resolved);
}
